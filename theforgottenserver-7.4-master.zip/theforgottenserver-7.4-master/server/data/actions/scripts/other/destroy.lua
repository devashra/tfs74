function onUse(player, item, fromPosition, target, toPosition)
	return destroyItem(player, target, toPosition)
end
